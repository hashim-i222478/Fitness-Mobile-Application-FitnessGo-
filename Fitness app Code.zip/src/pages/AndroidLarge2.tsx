import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./AndroidLarge2.module.css";

const AndroidLarge2: FunctionComponent = () => {
  const navigate = useNavigate();

  const onCONTINUETextClick = useCallback(() => {
    navigate("/android-large-4");
  }, [navigate]);

  const onBACKTextClick = useCallback(() => {
    navigate("/android-large-1");
  }, [navigate]);

  return (
    <div className={styles.androidLarge2}>
      <div className={styles.blackMonochromePortraitDark} />
      <b className={styles.chooseYourFocus}>CHOOSE YOUR FOCUS AREA</b>
      <b className={styles.fitnessGo}>FITNESS GO</b>
      <img className={styles.pngkey1Icon} alt="" src="/pngkey-1@2x.png" />
      <div className={styles.androidLarge2Child} />
      <div className={styles.androidLarge2Item} />
      <div className={styles.androidLarge2Inner} />
      <div className={styles.rectangleDiv} />
      <div className={styles.abs}>ABS</div>
      <div className={styles.androidLarge2Child1} />
      <div className={styles.fullBody}>Full Body</div>
      <div className={styles.chest}>CHEST</div>
      <div className={styles.arms}>ARMS</div>
      <img className={styles.lineIcon} alt="" src="/line-1.svg" />
      <img className={styles.androidLarge2Child2} alt="" src="/line-2.svg" />
      <img className={styles.androidLarge2Child3} alt="" src="/line-3.svg" />
      <div className={styles.legs}>LEGS</div>
      <img className={styles.androidLarge2Child4} alt="" src="/line-4.svg" />
      <div className={styles.congratulationsYouAreContainer}>
        <span className={styles.congratulationsYouAreContainer1}>
          <p className={styles.congratulations}>Congratulations!</p>
          <p className={styles.congratulations}>
            {" "}
            You Are One Step closer to your dream Physic.
          </p>
        </span>
      </div>
      <div className={styles.androidLarge2Child5} />
      <b className={styles.continue} onClick={onCONTINUETextClick}>
        <p className={styles.congratulations}>CONTINUE</p>
      </b>
      <div className={styles.back} onClick={onBACKTextClick}>
        BACK
      </div>
      <div className={styles.lineDiv} />
      <img className={styles.arrowIcon} alt="" src="/arrow-4.svg" />
    </div>
  );
};

export default AndroidLarge2;
