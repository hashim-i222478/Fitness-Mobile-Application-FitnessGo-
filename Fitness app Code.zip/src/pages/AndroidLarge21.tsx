import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./AndroidLarge21.module.css";

const AndroidLarge21: FunctionComponent = () => {
  const navigate = useNavigate();

  const onBACKTextClick = useCallback(() => {
    navigate("/");
  }, [navigate]);

  const onDontHaveAnClick = useCallback(() => {
    navigate("/android-large-3");
  }, [navigate]);

  const onRectangle3Click = useCallback(() => {
    navigate("/android-large-1");
  }, [navigate]);

  return (
    <div className={styles.androidLarge2}>
      <div className={styles.back} onClick={onBACKTextClick}>
        BACK
      </div>
      <img className={styles.androidLarge2Child} alt="" src="/arrow-21.svg" />
      <b className={styles.welcomeToFitnessgo}>Welcome to FitnessGo</b>
      <div className={styles.dontHaveAnContainer} onClick={onDontHaveAnClick}>
        <span className={styles.dontHaveAnContainer1}>
          <p className={styles.dontHaveAn}>Don’t have an account</p>
          <p className={styles.dontHaveAn}>Create new account</p>
        </span>
      </div>
      <div className={styles.loginToYour}>
        Login to your account to get started
      </div>
      <b className={styles.userName}>User Name:</b>
      <div className={styles.androidLarge2Item} />
      <div className={styles.androidLarge2Inner} />
      <div className={styles.rectangleDiv} />
      <b className={styles.emailAddress}>Email Address:</b>
      <b className={styles.password}>Password:</b>
      <img className={styles.pngegg71} alt="" src="/pngegg-7-1@2x.png" />
      <div className={styles.androidLarge2Child1} onClick={onRectangle3Click} />
      <b className={styles.login}>LOGIN</b>
    </div>
  );
};

export default AndroidLarge21;
