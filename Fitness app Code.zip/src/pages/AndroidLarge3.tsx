import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./AndroidLarge3.module.css";

const AndroidLarge3: FunctionComponent = () => {
  const navigate = useNavigate();

  const onBACKTextClick = useCallback(() => {
    navigate("/android-large-2");
  }, [navigate]);

  const onSIGNUPTextClick = useCallback(() => {
    navigate("/android-large-1");
  }, [navigate]);

  return (
    <div className={styles.androidLarge3}>
      <b className={styles.fitnessGo}>Fitness Go</b>
      <div className={styles.back} onClick={onBACKTextClick}>
        BACK
      </div>
      <img className={styles.androidLarge3Child} alt="" src="/arrow-11.svg" />
      <b className={styles.enterName}>{`ENTER NAME: `}</b>
      <b className={styles.enterEmail}>ENTER EMAIL:</b>
      <div className={styles.createAccount}>Create Account</div>
      <b className={styles.password}>PASSWORD:</b>
      <b className={styles.reEnterPassword}>{`    RE-ENTER PASSWORD: `}</b>
      <div className={styles.androidLarge3Item} />
      <div className={styles.androidLarge3Inner} />
      <div className={styles.rectangleDiv} />
      <div className={styles.androidLarge3Child1} />
      <div className={styles.androidLarge3Child2} />
      <b className={styles.signUp} onClick={onSIGNUPTextClick}>
        SIGN UP
      </b>
      <div className={styles.enterYourInformation}>
        Enter your information below to get started
      </div>
      <div className={styles.pressSignupTo}>
        Press signup to create your account
      </div>
    </div>
  );
};

export default AndroidLarge3;
