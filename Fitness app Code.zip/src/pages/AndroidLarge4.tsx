import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./AndroidLarge4.module.css";

const AndroidLarge4: FunctionComponent = () => {
  const navigate = useNavigate();

  const onBACKTextClick = useCallback(() => {
    navigate("/android-large-21");
  }, [navigate]);

  return (
    <div className={styles.androidLarge4}>
      <div className={styles.androidLarge4Child} />
      <b className={styles.workoutPlans}>{`WORKOUT PLANS `}</b>
      <b className={styles.muscleBuilding}>MUSCLE BUILDING</b>
      <img className={styles.ss1Icon} alt="" src="/ss-1@2x.png" />
      <img className={styles.sss1Icon} alt="" src="/sss-1@2x.png" />
      <div className={styles.androidLarge4Item} />
      <div className={styles.androidLarge4Inner} />
      <div className={styles.rectangleDiv} />
      <div className={styles.androidLarge4Child1} />
      <b className={styles.bigginer}>BIGGINER</b>
      <div className={styles.androidLarge4Child2} />
      <div className={styles.androidLarge4Child3} />
      <b className={styles.months}>{`6 MONTHS `}</b>
      <b className={styles.months1}>{`6 MONTHS `}</b>
      <b className={styles.months2}>3 MONTHS</b>
      <b className={styles.months3}>3 MONTHS</b>
      <b className={styles.fatLoss}>FAT LOSS</b>
      <img className={styles.s1Icon} alt="" src="/s-1@2x.png" />
      <img className={styles.s21Icon} alt="" src="/s2-1@2x.png" />
      <b className={styles.powerLifting}>{`POWER LIFTING `}</b>
      <img className={styles.sp21Icon} alt="" src="/sp2-1@2x.png" />
      <img className={styles.sp31Icon} alt="" src="/sp3-1@2x.png" />
      <b className={styles.advanced}>
        <p className={styles.advanced1}>ADVANCED</p>
      </b>
      <div className={styles.fitnessGoProvides}>
        FITNESS GO provides you workout plans according to your desire
      </div>
      <div className={styles.back} onClick={onBACKTextClick}>
        BACK
      </div>
      <img className={styles.arrowIcon} alt="" src="/arrow-4.svg" />
    </div>
  );
};

export default AndroidLarge4;
