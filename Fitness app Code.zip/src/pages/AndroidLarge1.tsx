import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./AndroidLarge1.module.css";

const AndroidLarge1: FunctionComponent = () => {
  const navigate = useNavigate();

  const onContinueTextClick = useCallback(() => {
    navigate("/android-large-2");
  }, [navigate]);

  return (
    <div className={styles.androidLarge1}>
      <img
        className={styles.edgarChaparroShfo3woggtuUnsIcon}
        alt=""
        src="/edgarchaparroshfo3woggtuunsplash-1@2x.png"
      />
      <div className={styles.androidLarge1Child} />
      <div className={styles.continue} onClick={onContinueTextClick}>
        Continue
      </div>
      <img className={styles.androidLarge1Item} alt="" src="/arrow-1.svg" />
      <div className={styles.androidLarge1Inner} />
      <div className={styles.fitnessGo}>FITNESS GO</div>
      <div className={styles.pressContinueTo}>
        Press continue to sign up/sign in
      </div>
      <div className={styles.aPerfectApp}>
        A perfect app to keep your body fit and healthy
      </div>
    </div>
  );
};

export default AndroidLarge1;
