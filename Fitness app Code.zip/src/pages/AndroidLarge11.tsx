import { FunctionComponent, useCallback } from "react";
import { useNavigate } from "react-router-dom";
import styles from "./AndroidLarge11.module.css";

const AndroidLarge11: FunctionComponent = () => {
  const navigate = useNavigate();

  const onCONTINUETextClick = useCallback(() => {
    navigate("/android-large-21");
  }, [navigate]);

  const onBACKTextClick = useCallback(() => {
    navigate("/android-large-3");
  }, [navigate]);

  return (
    <div className={styles.androidLarge1}>
      <img className={styles.androidLarge1Child} alt="" />
      <div className={styles.blackMonochromePortraitDark} />
      <b className={styles.fitnessGo}>FITNESS GO</b>
      <b className={styles.selectYourGender}>Select your Gender:</b>
      <div className={styles.androidLarge1Item} />
      <div className={styles.androidLarge1Inner} />
      <b className={styles.male}>MALE</b>
      <b className={styles.female}>FEMALE</b>
      <b className={styles.enterYourHeight}>Enter your Height:</b>
      <div className={styles.rectangleDiv} />
      <div className={styles.androidLarge1Child1} />
      <b className={styles.ft}>ft.</b>
      <b className={styles.in}>in.</b>
      <b className={styles.enterYourWeight}>Enter Your Weight:</b>
      <div className={styles.androidLarge1Child2} />
      <div className={styles.androidLarge1Child3} />
      <div className={styles.androidLarge1Child4} />
      <b className={styles.continue} onClick={onCONTINUETextClick}>
        <p className={styles.continue1}>CONTINUE</p>
      </b>
      <b className={styles.kg}>kg</b>
      <b className={styles.enterYourAge}>{`Enter Your Age: `}</b>
      <b className={styles.yrs}>
        <p className={styles.continue1}>yrs</p>
      </b>
      <img
        className={styles.pngtreehandDrawnWindAbdomi}
        alt=""
        src="/pngtreehand-drawn-wind-abdominal-muscle-5751015-1@2x.png"
      />
      <img
        className={styles.pngtreehandDrawnWindAbdomi1}
        alt=""
        src="/pngtreehand-drawn-wind-abdominal-muscle-5751015-2@2x.png"
      />
      <div className={styles.createYourProfile}>Create your Profile</div>
      <img className={styles.lineIcon} alt="" src="/line-5.svg" />
      <img className={styles.androidLarge1Child5} alt="" src="/line-6.svg" />
      <div className={styles.back} onClick={onBACKTextClick}>
        BACK
      </div>
      <img className={styles.arrowIcon} alt="" src="/arrow-2@2x.png" />
    </div>
  );
};

export default AndroidLarge11;
