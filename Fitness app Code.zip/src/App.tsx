import {
  Routes,
  Route,
  useNavigationType,
  useLocation,
} from "react-router-dom";
import AndroidLarge1 from "./pages/AndroidLarge1";
import AndroidLarge4 from "./pages/AndroidLarge4";
import AndroidLarge11 from "./pages/AndroidLarge11";
import AndroidLarge2 from "./pages/AndroidLarge2";
import AndroidLarge3 from "./pages/AndroidLarge3";
import AndroidLarge21 from "./pages/AndroidLarge21";
import { useEffect } from "react";

function App() {
  const action = useNavigationType();
  const location = useLocation();
  const pathname = location.pathname;

  useEffect(() => {
    if (action !== "POP") {
      window.scrollTo(0, 0);
    }
  }, [action, pathname]);

  useEffect(() => {
    let title = "";
    let metaDescription = "";

    switch (pathname) {
      case "/":
        title = "";
        metaDescription = "";
        break;
      case "/android-large-4":
        title = "";
        metaDescription = "";
        break;
      case "/android-large-1":
        title = "";
        metaDescription = "";
        break;
      case "/android-large-21":
        title = "";
        metaDescription = "";
        break;
      case "/android-large-3":
        title = "";
        metaDescription = "";
        break;
      case "/android-large-2":
        title = "";
        metaDescription = "";
        break;
    }

    if (title) {
      document.title = title;
    }

    if (metaDescription) {
      const metaDescriptionTag: HTMLMetaElement | null = document.querySelector(
        'head > meta[name="description"]'
      );
      if (metaDescriptionTag) {
        metaDescriptionTag.content = metaDescription;
      }
    }
  }, [pathname]);

  return (
    <Routes>
      <Route path="/" element={<AndroidLarge1 />} />
      <Route path="/android-large-4" element={<AndroidLarge4 />} />
      <Route path="/android-large-1" element={<AndroidLarge11 />} />
      <Route path="/android-large-21" element={<AndroidLarge2 />} />
      <Route path="/android-large-3" element={<AndroidLarge3 />} />
      <Route path="/android-large-2" element={<AndroidLarge21 />} />
    </Routes>
  );
}
export default App;
